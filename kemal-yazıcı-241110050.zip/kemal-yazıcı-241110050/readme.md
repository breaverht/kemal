Bu proje, 5 sayfalık bir kişisel veya kurumsal web sitesi geliştirmeyi amaçlamaktadır.

## Sayfalar
- *Anasayfa*: Hoş geldiniz mesajı.
- *Hakkımızda*: Kişisel bilgiler.
- *Projeler*: Proje tanıtımları.
- *Blog*: Haber.
- *İletişim*: İletişim formu.

## Kullanım
Web sitesini görüntülemek için HTML dosyalarını bir tarayıcıda açabilirsiniz.